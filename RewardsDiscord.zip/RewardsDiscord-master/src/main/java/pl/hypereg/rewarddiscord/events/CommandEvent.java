package pl.hypereg.rewarddiscord.events;

import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import pl.hypereg.rewarddiscord.MainRewards;
import pl.hypereg.rewarddiscord.utils.ColorFixUtil;

import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

public class CommandEvent extends ListenerAdapter {

    MainRewards mainRewards = MainRewards.getPlugin(MainRewards.class);
    private String[] argsGlobal;

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        Message msg = event.getMessage();
        if (msg.getContentRaw().startsWith(mainRewards.getConfig().getString("config.command.name"))) {

            String[] args = event.getMessage().getContentDisplay().split(" ");
            Player player = Bukkit.getPlayerExact(args[1]);
            argsGlobal = args;
            event.getMessage().delete().queue();
            if(player == null){
                event.getChannel().sendMessage(mainRewards.getConfig().getString("config.message.failed.nullplayer")).queue(m -> m.delete().queueAfter(5, TimeUnit.SECONDS));
            } else {
                gotoReward(event, player);
            }
        }
    }

    private void gotoReward(MessageReceivedEvent event, Player player){
        new BukkitRunnable() {
            @Override
            public void run() {
                mainRewards.getConfig().getStringList("config.execute.command").forEach(string -> Bukkit.getServer().dispatchCommand(Bukkit.getServer().getConsoleSender(), string.replaceAll("%player%", player.getName())));
                mainRewards.getConfig().getStringList("config.execute.broadcast").stream().map(string -> ColorFixUtil.FixColor(string.replaceAll("%player%", player.getName()))).forEach(Bukkit::broadcastMessage);
                player.sendMessage(ColorFixUtil.FixColor(mainRewards.getConfig().getString("config.message.getreward.game").replaceAll("%player%", player.getName())));
                event.getChannel().sendMessage(mainRewards.getConfig().getString("config.message.getreward.discord").replaceAll("%player%", player.getName())).queue(m -> m.delete().queueAfter(5, TimeUnit.SECONDS));
            }
        }.runTask(mainRewards);
    }
}
