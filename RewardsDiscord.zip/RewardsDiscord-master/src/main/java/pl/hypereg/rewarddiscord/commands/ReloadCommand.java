package pl.hypereg.rewarddiscord.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitScheduler;
import org.jetbrains.annotations.NotNull;
import pl.hypereg.rewarddiscord.MainRewards;
import pl.hypereg.rewarddiscord.utils.ColorFixUtil;

public class ReloadCommand implements CommandExecutor {

    private final MainRewards mainRewards = MainRewards.getPlugin(MainRewards.class);

    @Override
    public boolean onCommand(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] strings) {
        Player player = (Player) commandSender;
        if(player.hasPermission(mainRewards.getConfig().getString("config.command.reload.permission"))) {
            player.sendMessage(ColorFixUtil.FixColor(mainRewards.getConfig().getString("config.command.reload.successful")));
            mainRewards.reloadConfig();
            mainRewards.saveConfig();
            return true;
        }else{
            player.sendMessage(ColorFixUtil.FixColor(mainRewards.getConfig().getString("config.command.reload.nopermission")));
            return false;
        }
    }
}