package pl.hypereg.rewarddiscord;

import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.requests.GatewayIntent;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import pl.hypereg.rewarddiscord.commands.ReloadCommand;
import pl.hypereg.rewarddiscord.events.CommandEvent;

import javax.security.auth.login.LoginException;
import java.util.Arrays;

public class MainRewards extends JavaPlugin {


    @Override
    public void onEnable() {
        try {
            registerDiscordJDA();
        } catch (LoginException e) {
            e.printStackTrace();
        } finally {
            registerConfigs();
            registerCommands();
        }
    }


    private void registerCommands(){
        this.getCommand("rewards-reload").setExecutor(new ReloadCommand());
    }

    @SuppressWarnings("")
    private void registerConfigs(){
        FileConfiguration config = this.getConfig();
        config.addDefault("config.token", "put discord token here");
        config.addDefault("config.command.name", "!reward");
        config.addDefault("config.command.reload.permission", "cmd.reward.reload");
        config.addDefault("config.command.reload.nopermission", "&e>> &7Niestety nie posiadasz wystarczających permisji");
        config.addDefault("config.command.reload.successful", "&e>> &7Pomyślnie zreloadowałeś config");
        config.addDefault("config.message.getreward.game", "&e>> &7Gratulacje, odebrałeś nagrode za dołączenie na discorda!");
        config.addDefault("config.message.getreward.discord", "&e>> &7Gratulacje, odebrałeś nagrode za dołączenie na discorda!");
        config.addDefault("config.message.failed.nullplayer", "&e>> &7Niestety takiej osoby nie ma w grze. Spróbuj ponownie później!");
        config.addDefault("config.message.failed.cooldown", "&e>> &7Odebrałeś niedawno nagrode. Spróbuj później");
        config.addDefault("config.execute.command", Arrays.asList("msg %player% siemano", "msg %player% sie2mano"));
        config.addDefault("config.execute.broadcast", Arrays.asList("&e>> &7Gratulacje, gracz o nicku %player% odebrał swoją nagrodę za dołączenie na discorda!", ""));
        config.options().copyDefaults(true);
        saveConfig();
    }

    private void registerDiscordJDA() throws LoginException {
        JDABuilder builder = JDABuilder.createDefault(getConfig().getString("config.token"),
                GatewayIntent.GUILD_MESSAGES, GatewayIntent.DIRECT_MESSAGES);
        builder.addEventListeners(new CommandEvent());
        builder.build();
    }
}