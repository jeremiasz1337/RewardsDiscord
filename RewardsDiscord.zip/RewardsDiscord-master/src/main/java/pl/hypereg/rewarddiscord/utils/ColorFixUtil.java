package pl.hypereg.rewarddiscord.utils;

import org.bukkit.ChatColor;

public class ColorFixUtil {
    public static String FixColor(String message){
        return ChatColor.translateAlternateColorCodes('&', message.replaceAll(">>", "»"));
    }
}
