# RewardsDiscord
🎉 Plugin for discord rewards.

If you have some idea for plugin you can open issues. 

TODO ✨
- Databse connection with cooldown
- Add more things

``config.yml``
```config:
  token: token here
  command:
    name: '!reward'
    reload:
      permission: cmd.reward.reload
      nopermission: '&e>> &7Niestety nie posiadasz wystarczających permisji'
      successful: '&e>> &7Pomyślnie zreloadowałeś config'
  message:
    getreward:
      game: '&e>> &7Gratulacje, odebrałeś nagrode za dołączenie na discorda!'
      discord: '&e>> &7Gratulacje, odebrałeś nagrode za dołączenie na discorda!'
    failed:
      nullplayer: '&e>> &7Niestety takiej osoby nie ma w grze. Spróbuj ponownie później!'
      cooldown: '&e>> &7Odebrałeś niedawno nagrode. Spróbuj później'
  execute:
    command:
    - msg %player% siemano
    - msg %player% sie2mano
    broadcast:
    - '&e>> &7Gratulacje, gracz o nicku %player% odebrał swoją nagrodę za dołączenie
      na discorda!'
    - ''
```
